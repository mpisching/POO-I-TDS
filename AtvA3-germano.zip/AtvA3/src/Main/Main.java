package Main;
import Domain.*;

public class Main {
    public static void main(String[] args) {

        //Marca
        Marca marca1 = new Marca();
        marca1.setNome("Ford");

        Marca marca2 = new Marca();
        marca2.setNome("Nissan");

        //Modelo
        Modelo modelo1 = new Modelo();
        modelo1.setCategoria(ECategoria.MEDIO);
        modelo1.setDescricao("SUV");
        modelo1.setMarca(marca1);

        Modelo modelo2 = new Modelo();
        modelo2.setCategoria(ECategoria.PADRAO);
        modelo2.setDescricao("Sedan");
        modelo2.setMarca(marca2);

        //Cor
        Cor cor1 = new Cor();
        cor1.setNome("Azul");

        Cor cor2 = new Cor();
        cor2.setNome("Cinza");

        //Veiculo
        Veiculo veiculo1 = new Veiculo();
        veiculo1.setId(0);
        veiculo1.setPlaca("abc-0000");
        veiculo1.setObservacoes("7 lugares");
        veiculo1.setModelo(modelo1);
        veiculo1.setCor(cor1);

        Veiculo veiculo2 = new Veiculo();
        veiculo2.setId(1);
        veiculo2.setPlaca("xyz-9999");
        veiculo2.setObservacoes("5 lugares");
        veiculo2.setModelo(modelo2);
        veiculo2.setCor(cor2);

        PessoaFisica pessoaFisica = new PessoaFisica();
        pessoaFisica.setId(1);
        pessoaFisica.setNome("Fulano");
        pessoaFisica.setCelular("(48)99168-0934");
        pessoaFisica.setEmail("fulano@mail.com");
        pessoaFisica.setDataCadastro(2025, 01, 22);
        pessoaFisica.setCpf("354.987.013-21");
        pessoaFisica.setDataNasc(1989, 01, 21);
        pessoaFisica.getPontuacao().setQuantidade(10);
        pessoaFisica.add(veiculo1);

        print(pessoaFisica, true);

        PessoaJuridica pessoaJuridica = new PessoaJuridica();
        pessoaJuridica.setId(1);
        pessoaJuridica.setNome("Ciclano");
        pessoaJuridica.setCelular("(48)99134-8778");
        pessoaJuridica.setEmail("ciclano@mail.com");
        pessoaJuridica.setDataCadastro(2025, 01, 23);
        pessoaJuridica.setCnpj("03.398.622/0001-00");
        pessoaJuridica.setInscricaoEstadual("143.476.922.884");
        pessoaJuridica.getPontuacao().setQuantidade(3);
        pessoaJuridica.add(veiculo1);
        pessoaJuridica.add(veiculo2);

        print(pessoaJuridica, true);

    }

    public static void print(Cliente cliente, boolean trueVeiculo){
        System.out.println("Cliente - " + cliente.getClass().getSimpleName());
        System.out.println(cliente.getDados());

        if (trueVeiculo){
            System.out.println(cliente.getDadosVeiculos());
        }

    }
}
