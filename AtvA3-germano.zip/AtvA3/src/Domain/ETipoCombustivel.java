package Domain;

public enum ETipoCombustivel {
    GASOLINA, ETANOL, FLEX, DIESEL, GNV, OUTROS;

}
