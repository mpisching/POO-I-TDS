package Domain;

public enum ECategoria {
    PEQUENO, MEDIO, GRANDE, MOTO, PADRAO;


}
