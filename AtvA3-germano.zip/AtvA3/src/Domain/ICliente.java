package Domain;

public interface ICliente {
    public String getDados();
    public String getDados(String obs);
}
