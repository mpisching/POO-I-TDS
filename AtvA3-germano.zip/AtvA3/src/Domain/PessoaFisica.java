package Domain;

import java.util.Date;

public class PessoaFisica extends Cliente {
    private String cpf;
    private Date dataNasc = new Date();

    public PessoaFisica() {

    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(Date dataNasc) {
        this.dataNasc = dataNasc;
    }

    public void setDataNasc(int ano, int mes, int dia) {
        this.dataNasc = new Date(ano - 1900, mes - 1, dia);
    }

    @Override
    public String getDados(){
        StringBuilder dados = new StringBuilder();
        dados.append(super.getDados());
        dados.append("CPF - ").append(this.cpf).append("\n");
        dados.append("Data de Nascimento - ").append(this.dataNasc).append("\n");
        return dados.toString();
    }

    @Override
    public String getDados(String obs){
        return null;
    }
}
