package Domain;

public class Pontuacao {
    private int quantidade;

    public Pontuacao() {
        this.quantidade = 0;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public int adicionar(int qtd){
        return this.quantidade + qtd;
    }

    public int subtrair(int qtd){
        return this.quantidade - qtd;
    }

    public int saldo(){
        return this.quantidade;
    }

    @Override
    public String toString(){
        return String.valueOf(quantidade);
    }

}
