package Domain;

public class PessoaJuridica extends Cliente {
    private String cnpj;
    private String inscricaoEstadual;

    public PessoaJuridica() {

    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getInscricaoEstadual() {
        return inscricaoEstadual;
    }

    public void setInscricaoEstadual(String inscricaoEstadual) {
        this.inscricaoEstadual = inscricaoEstadual;
    }

    @Override
    public String getDados(){
        StringBuilder dados = new StringBuilder();
        dados.append(super.getDados());
        dados.append("CNPJ - ").append(this.cnpj).append("\n");
        dados.append("Inscrição Estadual - ").append(this.inscricaoEstadual).append("\n");
        return dados.toString();
    }

    @Override
    public String getDados(String obs){
        return null;
    }
}
